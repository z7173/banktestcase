package example;

public class PrintVer {

 static public void print(Version ver) {
  System.out.println(ver);
 }

}
