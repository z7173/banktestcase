The jython.jar file should be placed in this directory.
